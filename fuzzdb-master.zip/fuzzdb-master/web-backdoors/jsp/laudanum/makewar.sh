#!/bin/sh

jar -cvf cmd.war warfiles/*
