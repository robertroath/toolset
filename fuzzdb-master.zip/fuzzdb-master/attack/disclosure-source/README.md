Notes:

**source-disc-cmd-exec-traversal.txt**

 single directory traversals that have caused showcode or command exec issues in the past
 
 ``` GET /path/*payload*relative/path/to/target/file/ ```

**source-disclosure-generic.txt**

known cross platform source Code, file disclosure attack patterns - append after file or dir path

**source-disclosure-microsoft.txt**

microsoft-specific - appends after filename - try the generic list for microsoft, too


