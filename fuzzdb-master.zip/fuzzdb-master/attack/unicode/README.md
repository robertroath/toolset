Many of the files in this directory originated from the project
https://github.com/minimaxir/big-list-of-naughty-strings
