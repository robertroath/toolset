
**traversals-8-deep-exotic-encoding.fuzz.txt**

Use Regex to replace {FILE} with your target filename

